public class CMYKtoRGB {
    public static void main(String[] args) {
        double cyan, magenta, yellow, black, white, red, green, blue;
        cyan = Double.parseDouble(args[0]);
        magenta = Double.parseDouble(args[1]);
        yellow = Double.parseDouble(args[2]);
        black = Double.parseDouble(args[3]);
        white = 1 - black;
        red = 255 * white * (1 - cyan);
        green = 255 * white * (1 - magenta);
        blue = 255 * white * (1 - yellow);
        System.out.printf("red   = %.0f\ngreen = %.0f\nblue  = %.0f", red, green, blue);
    }
}
