/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

public class Ramanujan {
    public static boolean isRamanujan(long n) {
        long newN = (long) Math.cbrt(n);
        long a = 0, b, c = 0, d;
        long placeholder;
        for (long i = 1; i < newN; i++) {
            placeholder = i * i * i;
            b = (long) Math.cbrt(n - placeholder);
            if ((placeholder + (b * b * b)) == n) {
                a = i;
                // StdOut.println("a : " + a + " b : " + b);
                break;
            }
        }
        for (long i = (a + 1); i < newN; i++) {
            placeholder = i * i * i;
            d = (long) Math.cbrt(n - placeholder);
            if ((placeholder + (d * d * d)) == n) {
                c = i;
                // StdOut.println("c : " + c + " d : " + d);
                break;
            }
        }
        if (a != 0 && c != 0 && a != c) {
            return true;
        }
        return false;

    }

    public static void main(String[] args) {
        long n = Long.parseLong(args[0]);
        // long endTime;
        // long startTime = System.currentTimeMillis();

        // if (isRamanujan(n)) {
        //     // endTime = System.currentTimeMillis();
        //     StdOut.println("true");
        // }
        // else {
        //     // endTime = System.currentTimeMillis();
        //     StdOut.println("false");
        // }
        StdOut.println(isRamanujan(n));

    }
}
