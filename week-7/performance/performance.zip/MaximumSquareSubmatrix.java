/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

public class MaximumSquareSubmatrix {
    // Returns the size of the largest contiguous square submatrix
    // of a[][] containing only 1s.
    public static int size(int[][] a) {
        int max = 0, rows = a.length, cols = a[0].length;
        int[][] dp = new int[rows][cols];
        for (int i = 1; i < rows; i++) {
            for (int j = 1; j < cols; j++) {
                if (a[i][j - 1] == 1 && a[i - 1][j - 1] == 1 && a[i - 1][j] == 1 && a[i][j] == 1) {
                    if (dp[i][j - 1] != 0 && dp[i - 1][j - 1] != 0 && dp[i - 1][j] != 0) {
                        dp[i][j] = dp[i - 1][j - 1] + 1;
                        max = (dp[i][j] > max) ? dp[i][j] : max;
                    }
                    else {
                        dp[i][j] = 2;
                        max = (max == 0) ? 2 : max;
                    }
                }
            }
        }
        return max;
    }

    public static void main(String[] args) {
        int matrixSize = StdIn.readInt();
        int[][] matrix = new int[matrixSize][matrixSize];
        for (int i = 0; i < matrixSize; i++) {
            for (int j = 0; j < matrixSize; j++) {
                matrix[i][j] = StdIn.readInt();
            }
        }
        int max = size(matrix);
        StdOut.println(max);
    }
}
